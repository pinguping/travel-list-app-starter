import React, { useState } from "react";

// New Item component
function Item({ item, onTogglePacked, onDelete }) {
  return (
    <li>
      <span
        style={{ textDecoration: item.packed ? "line-through" : "none", cursor: "pointer" }}
        onClick={() => onTogglePacked(item.id)}
      >
        {item.quantity} x {item.description}
      </span>
      <button onClick={() => onDelete(item.id)} style={{ marginLeft: "10px", color: "red" }}>
        X
      </button>
    </li>
  );
}

function Logo() {
  return <h1>My Travel List</h1>;
}

function Form({ handleAddItem }) {
  const [description, setDescription] = useState("");
  const [quantity, setQuantity] = useState("1");

  function handleSubmit(e) {
    e.preventDefault();

    const newItem = {
      id: Date.now(), // Unique ID
      description: description.trim(),
      quantity: quantity,
      packed: false,
    };

    handleAddItem(newItem);

    // Reset form fields
    setDescription("");
    setQuantity("1");
  }

  return (
    <form className="add-form" onSubmit={handleSubmit}>
      <h3>What do you need to pack?</h3>

      <label htmlFor="quantity"></label>
      <select
        id="quantity"
        name="quantity"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
      >
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
      </select>

      <label htmlFor="item-description"></label>
      <input
        type="text"
        id="item-description"
        name="description"
        placeholder="Item..."
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />

      <button type="submit">Add</button>
    </form>
  );
}

function PackingList({ items, onTogglePacked, onDelete }) {
  return (
    <div className="list">
      <ul>
        {items.map((item) => (
          <Item
            key={item.id}
            item={item}
            onTogglePacked={onTogglePacked}
            onDelete={onDelete}
          />
        ))}
      </ul>
    </div>
  );
}

function Stats({ items }) {
  const packedItems = items.filter((item) => item.packed).length;
  const totalItems = items.length;
  const percentage = totalItems ? Math.round((packedItems / totalItems) * 100) : 0;

  return (
    <footer className="stats">
      <em>
        You have {totalItems} items in the list. You already packed {packedItems} ({percentage}%).
      </em>
    </footer>
  );
}

function App() {
  const [items, setItems] = useState([]);

  function handleAddItem(newItem) {
    setItems((prevItems) => [...prevItems, newItem]);
  }

  function handleTogglePacked(id) {
    setItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, packed: !item.packed } : item
      )
    );
  }

  function handleDeleteItem(id) {
    setItems((prevItems) => prevItems.filter((item) => item.id !== id));
  }

  return (
    <div className="app">
      <Logo />
      <Form handleAddItem={handleAddItem} />
      <PackingList
        items={items}
        onTogglePacked={handleTogglePacked}
        onDelete={handleDeleteItem}
      />
      <Stats items={items} />
    </div>
  );
}

export default App;
